[TuyaOS 蓝牙快速入门](https://www.tuyaos.com/viewtopic.php?t=12)
