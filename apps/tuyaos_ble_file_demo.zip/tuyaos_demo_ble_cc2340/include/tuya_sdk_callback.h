/**
 * @file tuya_sdk_callback.h
 * @brief This is tuya_sdk_callback file
 * @version 1.0
 * @date 2021-09-10
 *
 * @copyright Copyright 2021-2023 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef __TUYA_SDK_CALLBACK_H__
#define __TUYA_SDK_CALLBACK_H__

#include "tuya_cloud_types.h"
#include "tal_uart.h"
#include "tal_bluetooth.h"

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************
 ********************* constant ( macro and enum ) *********************
 **********************************************************************/
#if (TUYA_SDK_TEST)
#define TUYA_DP_TEST 0
// If need TUYA_DP_TEST, please disable TUYA_DISTANCE_TEST
#define TUYA_DISTANCE_TEST 0
#else
#define TUYA_DP_TEST 0
#define TUYA_DISTANCE_TEST 0
#endif

#if (TUYA_DP_TEST)

#define DP_TEST_BOARD_TI                          0
#define DP_TEST_BOARD_TUYA_V1                     1
#define DP_TEST_BOARD_TUYA_V2                     2
#define DP_TEST_BOARD_TYPE                        DP_TEST_BOARD_TUYA_V1

// Valid Level
#if (DP_TEST_BOARD_TYPE == DP_TEST_BOARD_TI)
#define DP_TEST_VALID_LEVEL                       TUYA_GPIO_LEVEL_HIGH
#define DP_TEST_INVALID_LEVEL                     TUYA_GPIO_LEVEL_LOW
#else
#define DP_TEST_VALID_LEVEL                       TUYA_GPIO_LEVEL_LOW
#define DP_TEST_INVALID_LEVEL                     TUYA_GPIO_LEVEL_HIGH
#endif // DP_TEST_BOARD_TYPE

// Pin
#if (DP_TEST_BOARD_TYPE == DP_TEST_BOARD_TI)
#define DP_TEST_PIN_CONNECT                      (TUYA_GPIO_NUM_14) // Red
#define DP_TEST_PIN_DATA                         (TUYA_GPIO_NUM_15) // Green
#elif (DP_TEST_BOARD_TYPE == DP_TEST_BOARD_TUYA_V1)
#define DP_TEST_PIN_CONNECT                      (TUYA_GPIO_NUM_23) // White
#define DP_TEST_PIN_DATA                         (TUYA_GPIO_NUM_14) // Green
#elif (DP_TEST_BOARD_TYPE == DP_TEST_BOARD_TUYA_V2)
#define DP_TEST_PIN_CONNECT                      (TUYA_GPIO_NUM_23) // White
#define DP_TEST_PIN_DATA                         (TUYA_GPIO_NUM_14) // Green
#endif // DP_TEST_BOARD_TYPE

#endif // TUYA_DP_TEST

/***********************************************************************
 ********************* struct ******************************************
 **********************************************************************/


/***********************************************************************
 ********************* variable ****************************************
 **********************************************************************/
extern TAL_UART_CFG_T tal_uart_cfg;
extern TAL_BLE_ADV_PARAMS_T tal_adv_param;
#if defined(TUYA_BLE_FEATURE_LONG_RANGE) && (TUYA_BLE_FEATURE_LONG_RANGE == 1)
extern TAL_BLE_EXT_ADV_PARAMS_T tal_ext_adv_param;
extern TAL_BLE_EXT_ADV_T tal_ext_adv_extended_adv; /*for extended advertiser*/
#endif

/***********************************************************************
 ********************* function ****************************************
 **********************************************************************/

/**
 * @brief
 *
 * @param[in] param1:
 * @param[in] param2:
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
UINT16_T tuya_app_get_conn_handle(VOID_T);


#ifdef __cplusplus
}
#endif

#endif /* __TUYA_SDK_CALLBACK_H__ */

