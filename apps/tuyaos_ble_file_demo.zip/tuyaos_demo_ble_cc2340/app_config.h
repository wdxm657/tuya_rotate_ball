/*************************************************************************************/
/* Automatically-generated file. Do not edit! */
/*************************************************************************************/

#ifndef __APP_CONFIG_H__
#define __APP_CONFIG_H__


//
// APP
//
#define ENABLE_LOG 1
#define BOARD_ENABLE_LOG 1
#define TUYA_SDK_TEST 1
#define TUYA_SDK_DEBUG_MODE 0
#define TUYA_BLE_FEATURE_LONG_RANGE 1
#define TUYA_BLE_USE_OS 1
#define TUYA_BLE_SELF_BUILT_TASK 1
#define TUYA_BLE_TASK_PRIORITY 2
#define TUYA_BLE_TASK_STACK_SIZE 4096
#define TUYA_NV_ERASE_MIN_SIZE 2048
#define TAL_GPIO_TEST_ENABLE 1
// end of APP

//
// COMP
//

//
// FW_INFO
//
#define FIRMWARE_NAME           "tuyaos_demo_ble_cc2340"
#define FIRMWARE_VERSION        "3.12.7"
#define FIRMWARE_VERSION_HEX    0x00030c07
#define HARDWARE_VERSION        "0.1.0"
#define HARDWARE_VERSION_HEX    0x00000100


#endif
