/*************************************************************************************/
/* Automatically-generated file. Do not edit! */
/*************************************************************************************/

#ifndef __APP_CONFIG_H__
#define __APP_CONFIG_H__


//
// APP
//
#define BOARD_HEAP_SIZE 12288
#define BOARD_TIMER_MAX_NUM 48
#define TUYA_BLE_AUTO_REQUEST_TIME_CONFIGURE 3
#define ENABLE_LOG 1
#define BOARD_ENABLE_LOG 1
#define TUYA_BLE_LOG_ENABLE 1
#define TUYA_SDK_TEST 1
#define TUYA_SDK_DEBUG_MODE 0
#define TUYA_BLE_MAX_CONNECTIONS 1
// end of APP

//
// COMP
//

//
// FW_INFO
//
#define FIRMWARE_NAME           "tuyaos_demo_ble_lock"
#define FIRMWARE_VERSION        "3.13.0"
#define FIRMWARE_VERSION_HEX    0x00030d00
#define HARDWARE_VERSION        "0.1.0"
#define HARDWARE_VERSION_HEX    0x00000100


#endif
